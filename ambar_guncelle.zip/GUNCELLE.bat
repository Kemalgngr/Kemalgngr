@echo off
cd /d "%~dp0"
python "%~dp0ambar_guncelle.py"
pause
